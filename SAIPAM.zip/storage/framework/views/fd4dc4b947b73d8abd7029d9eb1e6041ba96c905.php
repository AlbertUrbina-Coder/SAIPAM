
<a href="/"><img src=<?php echo e(asset('../logoA&M_negro.png')); ?> alt="" width="100px"></a>
<?php /**PATH C:\AppServ\www\SAIPAM\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>