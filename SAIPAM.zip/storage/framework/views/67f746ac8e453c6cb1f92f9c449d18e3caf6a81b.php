<?php $__env->startSection('title', 'Productores'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
        <h1 class="page-header">Nuevo Productor</h1>
    </div>

<form action="/productores" method="post" enctype="multipart/form-data" autocomplete="off">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label>Nombre</label>
        <input class="form-control" type="text" name="nombreProductor" id="nombreProductor" placeholder="Ingrese su Nombre Completo" required="">
    </div>

    <div class="form-group">
        <label>Tipo de documento</label>
        <select class="form-control" name="tipoDocumento" placeholder="Selecciones el tipo de documento">
            <option>Tarjeta de Identidad</option>
            <option selected>Cédula de Ciudadanía</option>
            <option>Cédula de Extranjería</option>
            <option>Pasaporte</option>
            <option>Documento de Identificación Extanjero</option>
            <option>Permiso Especial de Permanencia PEP</option>
        </select>
    </div>

    <div class="form-group">
        <label>N° Documento</label>
        <input class="form-control" type="text" name="numDocumento" id="numDocumento" placeholder="Ingrese su numero de documento" required="">
    </div>

    <div class="form-group">
        <label>Ciudad</label>
        <select class="form-control" type="text" name="ciudad" id="ciudad" required="">
            <option selected value="110">Bogotá, D.C.</option>
            <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ciudad['id']); ?>"><?php echo e($ciudad['nombreCiudad']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
    </div>

    <div class="form-group">
        <label>Dirección</label>
        <input class="form-control" type="text" name="direccion" id="direccion" placeholder="Ingrese su dirección" required="">
    </div>

    <div class="form-group">
        <label>Correo</label>
        <input class="form-control" type="email" name="correo" id="correo" placeholder="Ingrese su correo electrónico" required="">
    </div>

    <div class="form-group">
        <label>Teléfono</label>
        <input class="form-control" type="text" name="telefono" id="telefono" placeholder="Ingrese su número de telefono" required="">
    </div>

    <div class="form-group">
        <label>Reg. MinCultura</label>
        <input class="form-control" type="text" name="registroMinCultura" id="registroMinCultura" placeholder="Ingrese su registro de MinCultura">
    </div>

    <hr />
    <div class="text-right">
        <a href="/productores" class="btn btn-secondary" tabindex="0">Cancelar</a>
        <button type="submit" class="btn btn-success" tabindex="0">Guardar</button>
    </div>
</form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/misEstilos.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\SAIPAM\resources\views//productores/create.blade.php ENDPATH**/ ?>