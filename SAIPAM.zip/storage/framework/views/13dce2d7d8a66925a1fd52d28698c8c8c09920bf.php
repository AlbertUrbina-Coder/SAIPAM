<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
        <h1 class="page-header">Nuevo Cliente</h1>
    </div>

<form action="/clientes" method="post" enctype="multipart/form-data" autocomplete="off">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label>Nombre</label>
        <input class="form-control" type="text" name="nombre" id="nombre" placeholder="Ingrese su Nombre Completo" required="">
    </div>

    <div class="form-group">
        <label>Ciudad</label>
        <select class="form-control" type="text" name="ciudad" id="ciudad" required="">
            <option selected value="110">Bogotá, D.C.</option>
            <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ciudad['id']); ?>"><?php echo e($ciudad['nombreCiudad']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
    </div>

    <div class="form-group">
        <label>Genero</label>
        <select class="form-control" type="text" name="genero" id="genero" required="">
            <option selected value="">Seleccione:</option>
            <option value="Hombre">Hombre</option>
            <option value="Mujer">Mujer</option>
            <option value="Indeterminado">Indeterminado</option>
          </select>
    </div>

    <div class="form-group">
        <label>Fecha de Nacimiento</label>
        <input class="form-control" type="date" name="fechaNacimiento" id="fecha" placeholder="Ingrese su fecha de nacimiento" required="">
    </div>

    <div class="form-group">
        <label>Teléfono</label>
        <input class="form-control" type="text" name="telefono" id="telefono" placeholder="Ingrese su número de telefono" required="">
    </div>

    <div class="form-group">
        <label>Correo</label>
        <input class="form-control" type="email" name="correo" id="correo" placeholder="Ingrese su dirección de correo electrónico" required="">
    </div>

    <hr />
    <div class="text-right">
        <a href="/clientes" class="btn btn-secondary" tabindex="0">Cancelar</a>
        <button type="submit" class="btn btn-success" tabindex="0">Guardar</button>
    </div>
</form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/misEstilos.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\SAIPAM\resources\views//clientes/create.blade.php ENDPATH**/ ?>