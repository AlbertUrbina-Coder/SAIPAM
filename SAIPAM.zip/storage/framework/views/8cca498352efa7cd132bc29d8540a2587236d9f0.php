<?php $__env->startSection('title', 'Eventos'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
        <h1 class="page-header">Editar Tipo Ticket</h1>
    </div>

<form action="<?php echo e(route('tipo_tickets.update', $tipoTicket['idTipoTicket'])); ?>" method="post" enctype="multipart/form-data" autocomplete="off">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <input type="hidden" name="idTipoTicket" value="<?php echo e($tipoTicket['idTipoTicket']); ?>" />

    <div class="form-group">
        <label>Eventos</label>
        <select class="form-control" type="text" name="evento" id="evento" required="">
            <option selected value="">Seleccione el productor encargado del evento:</option>
            <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($evento['idEvento']); ?>"><?php echo e($evento['titulo']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
    </div>

    <div class="form-group">
        <label>Sector</label>
        <input class="form-control" type="text" name="sector" id="titulo" value="<?php echo e($tipoTicket['sector']); ?>" required="">
    </div>

    <div class="form-group">
        <label>Descripción</label>
        <input class="form-control" type="text" name="descripcion" id="descripcion" value="<?php echo e($tipoTicket['descripcion']); ?>" required="">
    </div>

    <div class="form-group">
        <label>Subtotal</label>
        <input class="form-control" type="text" name="subtotal" id="subtotal" value="<?php echo e($tipoTicket['subtotal']); ?>">
    </div>

    <div class="form-group">
        <label>IVA</label>
        <input class="form-control" type="text" name="iva" id="iva" value="<?php echo e($tipoTicket['iva']); ?>">
    </div>

    <div class="form-group">
        <label> Valor Total</label>
        <input readonly class="form-control" type="text" name="valorTotal" id="valorTotal" value="<?php echo e($tipoTicket['valorTotal']); ?>">
    </div>

    <div class="form-group">
        <label>Cantidad Total</label>
        <input class="form-control" type="text" name="cantidadTotal" id="cantidadTotal" value="<?php echo e($tipoTicket['cantidadTotal']); ?>">
    </div>

    <div class="form-group">
        <label>Cantidad Vendida</label>
        <input class="form-control" type="text" name="cantidadVendida" id="cantidadVendida" value="<?php echo e($tipoTicket['cantidadVendida']); ?>">
    </div>

    <hr />
    <div class="text-right">
        <a href="/tipo_tickets" class="btn btn-secondary" tabindex="0">Cancelar</a>
        <button type="submit" class="btn btn-success" tabindex="0">Actualizar</button>
    </div>
</form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/misEstilos.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\SAIPAM\resources\views/tipo_tickets/edit.blade.php ENDPATH**/ ?>