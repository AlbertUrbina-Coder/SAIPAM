<?php $__env->startSection('title', 'Locaciones'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
        <h1 class="page-header">Editar Locación</h1>
    </div>

<form action="<?php echo e(route('locaciones.update', $locacion->idLocacion)); ?>" method="post" enctype="multipart/form-data" autocomplete="off">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <input type="hidden" name="id" value="<?php echo e($locacion['idLocacion']); ?>" />

    <div class="form-group">
        <label>Tipo de Locación</label>
        <select class="form-control" name="tipoLocacion" value="<?php echo e($locacion['tipoLocacion']); ?>">
            <option selected>Teatro</option>
            <option>Sala de conciertos</option>
            <option>Campo abierto</option>
            <option>Auditorio</option>
            <option>Auditorio de Hotel</option>
            <option>Parque</option>
            <option>Estacionamiento</option>
        </select>
    </div>

    <div class="form-group">
        <label>Nombre Locación</label>
        <input class="form-control" type="text" name="nombreLocacion" id="nombreLocacion" value="<?php echo e($locacion['nombreLocacion']); ?>" required>
    </div>

    <div class="form-group">
        <label>Ciudad</label>
        <select class="form-control" type="text" name="ciudad" id="ciudad" required>
            <option selected value="110">Bogotá, D.C.</option>
            <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ciudad['id']); ?>"><?php echo e($ciudad['nombreCiudad']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
    </div>

    <div class="form-group">
        <label>Capacidad</label>
        <input class="form-control" type="text" name="capacidad" id="capacidad" value="<?php echo e($locacion['capacidad']); ?>" required>
    </div>

    <div class="form-group">
        <label>Dirección</label>
        <input class="form-control" type="text" name="direccion" id="direccion" value="<?php echo e($locacion['direccion']); ?>" required>
    </div>

    <div class="form-group">
        <label>Correo de contacto</label>
        <input class="form-control" type="email" name="correo" id="correo" value="<?php echo e($locacion['correoContacto']); ?>" required>
    </div>

    <div class="form-group">
        <label>Valor Alquiler</label>
        <input class="form-control" type="text" name="valorAlquiler" id="valorAlquiler" value="<?php echo e($locacion['valorAlquiler']); ?>">
    </div>

    <hr />
    <div class="text-right">
        <a href="/locaciones" class="btn btn-secondary" tabindex="0">Cancelar</a>
        <button type="submit" class="btn btn-success" tabindex="0">Actualizar</button>
    </div>
</form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/misEstilos.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\SAIPAM\resources\views/locaciones/edit.blade.php ENDPATH**/ ?>