<?php $__env->startSection('title', 'Ciudades'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <h1 class="page-header">Editar Cliente</h1>
    </div>

    <form action="<?php echo e(route('clientes.update', $cliente->idCliente)); ?>" method="post" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="hidden" name="id" value="<?php echo e($cliente['idCliente']); ?>" />

        <div class="form-group">
            <label>Nombre</label>
            <input class="form-control" type="text" name="nombre" id="nombre" value="<?php echo e($cliente['nombreCliente']); ?>" required="">
        </div>

        <div class="form-group">
            <label>Ciudad</label>
            <select class="form-control" type="text" name="ciudad" id="ciudad" required="">
                <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ciudad['id']); ?>"><?php echo e($ciudad['nombreCiudad']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label>Genero</label>
            <select class="form-control" type="text" name="genero" id="genero" required="">
                <option selected value="">Seleccione:</option>
                <option value="Hombre">Hombre</option>
                <option value="Mujer">Mujer</option>
                <option value="Indeterminado">Indeterminado</option>
            </select>
        </div>

        <div class="form-group">
            <label>Fecha de Nacimiento</label>
            <input class="form-control" type="date" name="fechaNacimiento" id="fecha" value="<?php echo e($cliente['fechaNacimiento']); ?>" required="">
        </div>

        <div class="form-group">
            <label>Telefono</label>
            <input class="form-control" type="text" name="telefono" id="telefono" value="<?php echo e($cliente['telefono']); ?>" required="">
        </div>

        <div class="form-group">
            <label>Correo</label>
            <input class="form-control" type="email" name="correo" id="correo" value="<?php echo e($cliente['correo']); ?>" required="">
        </div>

        <hr />
        <div class="text-right">
            <a href="/clientes" class="btn btn-secondary" tabindex="0">Cancelar</a>
            <button type="submit" class="btn btn-success" tabindex="0">Guardar</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/misEstilos.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\SAIPAM\resources\views/clientes/edit.blade.php ENDPATH**/ ?>