<?php $__env->startSection('title', 'Productores'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div class="well well-sm text-right">
            <h1 class="page-header" style="float:left; margin:auto; padding:auto;">Listado de Productores</h1>
            <a class="btn btn-primary agregar" href='<?php echo e(url('/productores/create')); ?>'>Agregar Productor</a>
        </div>


        <div >
        <table id="clientes" class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Tipo Documento</th>
                    <th>Número Documento</th>
                    <th>Ciudad</th>
                    <th>Dirección</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Reg. MinCultura</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $productores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($productor->nombreProductor); ?></td>
                    <td><?php echo e($productor->tipoDocumento); ?></td>
                    <td><?php echo e($productor->numeroDocumento); ?></td>
                    <td><?php echo e($productor->idCiudad); ?></td>
                    <td><?php echo e($productor->direccion); ?></td>
                    <td><?php echo e($productor->correo); ?></td>
                    <td><?php echo e($productor->telefono); ?></td>
                    <td><?php echo e($productor->registroMinCultura); ?></td>

                    <td>
                        <form action="<?php echo e(route('productore.destroy', $productor->idProductor)); ?>" method="post" class="formAcciones">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        <a href="/productore/<?php echo e($productor->idProductor); ?>/edit" class="btn btn-link btnEditar"><i class="fas fa-pencil-alt iconos"></i>&nbsp; Editar</a>
                        <button type="submit" class="btn btn-link"><i class="fas fa-trash-alt iconos"></i>&nbsp; Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.2/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/misEstilos.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://kit.fontawesome.com/4de87f4a32.js" crossorigin="anonymous"></script>
    <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src=" https://cdn.datatables.net/1.11.2/js/jquery.dataTables.min.js"></script>
    <script src=" https://cdn.datatables.net/1.11.2/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#ciudades').DataTable({
                "lengthMenu": [[5,10,20,50,-1],[5,10,20,50,"All"]]
            });
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\SAIPAM\resources\views//productores/index.blade.php ENDPATH**/ ?>