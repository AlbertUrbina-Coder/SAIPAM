<?php $__env->startSection('title', 'Ciudades'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="page-header">Editar Ciudad</h1>

    <ol class="breadcrumb">
      <li><a href="/ciudades">Ciudades</a></li>
      <li class="active"><?php echo e($ciudad['nombreCiudad']); ?></li>
    </ol>

<form action="/ciudades/<?php echo e($ciudad['id']); ?>" method="post" autocomplete="off">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <input type="hidden" name="idCiudad" value="<?php echo e($ciudad['id']); ?>" />

    <div class="form-group">
        <div class="form-group">
	        <label>Pais</label>
	        <input class="form-control" type="text" name="pais" value="<?php echo e($country['nombre']); ?>" required="">
	    </div>
    </div>

    <div class="form-group">
        <div class="form-group">
	        <label>Nombre</label>
	        <input class="form-control" type="text" name="nombre" value="<?php echo e($ciudad['nombreCiudad']); ?>" required="">
	    </div>
    </div>
	    <hr />
	    <div class="text-right">
            <a href="/ciudades" class="btn btn-secondary">Cancelar</a>
        	<button type="submit" class="btn btn-success">Guardar</button>
	    </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/misEstilos.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\SAIPAM\resources\views/ciudades/edit.blade.php ENDPATH**/ ?>