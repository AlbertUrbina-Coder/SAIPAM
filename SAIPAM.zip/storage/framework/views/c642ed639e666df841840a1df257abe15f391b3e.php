<?php $__env->startSection('title', 'Tickets'); ?>

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div>
        <h1 class="page-header">Nuevo Tipo de Ticket</h1>
    </div>

<form action="/tickets" method="post" enctype="multipart/form-data" autocomplete="off">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label>Eventos</label>
        <select class="form-control" type="text" name="evento" id="evento" required="">
            <option selected value="">Seleccione el productor encargado del evento:</option>
            <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($evento['idEvento']); ?>"><?php echo e($evento['titulo']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
    </div>

    <div class="form-group">
        <label>Tipo Ticket</label>
        <select class="form-control" type="text" name="tipoTicket" id="tipoTicket" required="">
            <option selected value="">Seleccione el productor encargado del evento:</option>
            <?php $__currentLoopData = $tipoTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoTicket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tipoTicket['idTipoTicket']); ?>"><?php echo e($tipoTicket['sector']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
    </div>

    <div class="form-group">
        <label>Cliente</label>
        <select class="form-control" type="text" name="cliente" id="cliente" required="">
            <option selected value="">Seleccione el productor encargado del evento:</option>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cliente['idCliente']); ?>"><?php echo e($cliente['nombreCliente']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
    </div>

    <div class="form-group">
        <label>Fila</label>
        <input class="form-control" type="text" name="fila" id="fila" placeholder="Ingrese el numero de fila">
    </div>

    <div class="form-group">
        <label>Silla</label>
        <input class="form-control" type="text" name="silla" id="silla" placeholder="Ingrese el numero de silla">
    </div>

    <div class="form-group">
        <label>Palco</label>
        <input class="form-control" type="text" name="palco" id="palco" placeholder="Ingrese el numero de palco">
    </div>

    <hr />
    <div class="text-right">
        <a href="/tickets" class="btn btn-secondary" tabindex="0">Cancelar</a>
        <button type="submit" class="btn btn-success" tabindex="0">Guardar</button>
    </div>
</form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="/css/misEstilos.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src=" https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\SAIPAM\resources\views//tickets/create.blade.php ENDPATH**/ ?>