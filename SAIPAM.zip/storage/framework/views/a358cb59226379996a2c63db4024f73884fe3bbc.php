<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php echo $__env->yieldContent('css'); ?>;

    <?php echo $__env->yieldContent('iconos'); ?>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/bootstrap-theme.css">
    <link rel="stylesheet" href="/css/misEstilos.css">

  </head>
  <body>
    <div class="container">
        <?php echo $__env->yieldContent('contenido'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>

    <?php echo $__env->yieldContent('js'); ?>
  </body>
</html>
<?php /**PATH C:\AppServ\www\SAIPAM\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>